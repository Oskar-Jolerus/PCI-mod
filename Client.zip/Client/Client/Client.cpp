//This is the Client.
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif

#define _WINSOCK_DEPRECATED_NO_WARNINGS

#include <windows.h>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <iphlpapi.h>
#include <stdio.h>
#include <iostream>

#pragma comment(lib, "Ws2_32.lib")

using namespace std;

int main() {

	int portNr = 4001;

	WSADATA wsaData;

	int iResult;
	// Initialize Winsock
	iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
	if (iResult != 0) {
		printf("WSAStartup failed: %d\n", iResult);
		return 1;
	}

	//Address that we will bind our listening socket to
	SOCKADDR_IN addr;
	//Length of the address
	int addrlen = sizeof(addr);
	//Broadcast locally
	addr.sin_addr.s_addr = inet_addr("192.168.10.253");
	//Port
	addr.sin_port = htons(portNr);
	addr.sin_family = AF_INET; //IPv4 Socket

	//Set a connection socket
	SOCKET connection = socket(AF_INET, SOCK_STREAM, NULL);
	if (connect(connection, (SOCKADDR*)&addr, sizeof(addr)) != 0) {
		cout << "Failed to Connect" << endl;
		return 1;
	}
	cout << "We are connected" << endl;
	char testStringClient[200];
	recv(connection, testStringClient, sizeof(testStringClient), NULL);
	cout << "Test message: " << testStringClient << endl;
	system("pause");

	return 0;
}

